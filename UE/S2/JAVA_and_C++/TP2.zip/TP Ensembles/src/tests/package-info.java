/**
 * Package contenant les classes de test
 */
package tests;