package listes;

import java.util.AbstractCollection;
import java.util.Iterator;

public class CollectionListe<E> extends AbstractCollection<E>{

	
	public CollectionListe()
	{
		tete = null;
	}
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
