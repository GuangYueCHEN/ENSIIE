<?php

include("tpVue.php");

enTete("Authentification");
vue_connexion();

pied();
?>

