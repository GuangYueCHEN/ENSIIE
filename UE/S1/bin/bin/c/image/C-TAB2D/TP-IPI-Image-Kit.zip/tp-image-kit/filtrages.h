#ifndef __FILTRAGES_H
#define __FILTRAGES_H

 unsigned char * filtrerMedianImageNB(unsigned char *src, int xs, int ys, int tailleFiltre,int *nc,int *nl);
 unsigned char * filtrerImageNB(unsigned char *src, int xs, int ys, int tailleFiltre,int *nc,int *nl);

#endif
