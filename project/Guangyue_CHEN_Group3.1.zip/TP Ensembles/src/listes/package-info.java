/**
 * Package contenant l'implémentation des listes simplement chainées définies
 * dans l'interface {@link listes.IListe} et implémentées dans la classe
 * {@link listes.Liste}
 */
package listes;