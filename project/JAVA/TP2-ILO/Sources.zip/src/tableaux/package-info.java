/**
 * Package contenant la classe {@link tableaux.Tableau} : tableau de données de
 * taille variable
 */
package tableaux;